import React from 'react';
import './shippingPriceList.css';
import Heading from '../Heading/Heading';

const ShippingPriceList = () => {

  const data = [
    { country: "USA (shipping by air)", deliveryTime: "3 - 6 working days", minimum: "none", volumetricWeight: "If there is no super volumetric weight", price: "6.000 AMD" },
    { country: "USA (shipping by sea)", deliveryTime:  "2 - 3 months", minimum: "up to 10 kg – 15.000 AMD", volumetricWeight: "", price: "1.500 AMD" },
    { country: "Russia (shipping by air)", deliveryTime: "2 - 5 working days", minimum: "up to 0.5 kg – 1.000 AMD", volumetricWeight: "If there is no super volumetric weight", price: "2.000 AMD" },
    { country: "United Kingdom", deliveryTime: "5 - 10 working days", minimum: "none", volumetricWeight: "If there is no super volumetric weight", price: "6.000 AMD" },
    { country: "China (shipping by air)", deliveryTime: "5 - 10 working days", minimum: "none", volumetricWeight: "If there is no super volumetric weight", price: "8.000 AMD" },
    { country: "China (shipping by sea)", deliveryTime: "≈ 2.5 months", minimum: "up to 1 kg – 1.500 amd", volumetricWeight: "", price: "1.500 AMD" },
    { country: "Dubai", deliveryTime: "4 - 8 working days", minimum: "none", volumetricWeight: "If there is no super volumetric weight", price: "5.000 AMD" },
  ]

  return (
    <div className='shippingpricelist'>
        <Heading heading = 'SHIPPING METHODS AND PRICES TO ARMENIA'/>
        <table>
          <thead>
          <tr>
            <th>ԵՐԿԻՐ</th>
            <th>ԱՌԱՔՄԱՆ ՏԵՎՈՂՈՒԹՅՈՒՆ</th>
            <th>ՄԻՆԻՄԱԼ</th>
            <th>ԾԱՎԱԼԱՅԻՆ ՔԱՇ</th>
            <th>ՍԱԿԱԳԻՆ (1ԿԳ)</th>
        </tr>
          </thead>

        {data.map((val, index) => {
          return (
            <tbody>
              <tr key={index}>
                <td>{val.country}</td>
                <td>{val.deliveryTime}</td>
                <td>{val.minimum}</td>
                <td>{val.volumetricWeight}</td>
                <td>{val.price}</td>
            </tr>
            </tbody>

          )
        })}
      </table>
    </div>
  )
}

export default ShippingPriceList