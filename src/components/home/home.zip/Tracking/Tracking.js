import React from 'react';
import './tracking.css'
import Heading from '../Heading/Heading';

const Tracking = () => {

  return (
    <div className='tracking'>
        <Heading heading = 'TRACK YOUR PARCEL' text = 'Insert the tracking number and track the delivery process.'/>
 
        <div className="trackInput">

            <input type="text" />
            <button> <i className='fas fa-search'></i> Search</button>
        </div>
    </div>
  )
}

export default Tracking