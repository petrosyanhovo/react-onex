import React from 'react';
import './heading.css';

const Heading = (props) => {

  return (
    <div className='heading'>
        <div className="stars">
            <i className='fas fa-star small'></i>
            <i className='fas fa-star middle'></i>
            <i className='fas fa-star big'></i>
            <i className='fas fa-star middle'></i>
            <i className='fas fa-star small'></i>
        </div>
        <h2>{props.heading}</h2>
        <p>{props.text}</p>
    </div>
  )
}

export default Heading