import React from 'react';
import './howToStart.css';
import Heading from '../Heading/Heading';
import step1 from '../HowToStart/img/step1.png'
import step2 from '../HowToStart/img/step2.png'
import step3 from '../HowToStart/img/step3.png'

const HowToStart = () => {
  return (
    <div className='howtostart'>
        <Heading 
                heading = 'HOW TO START' 
                text = 'How to make online purchases and get fast and secure in Armenia?'
            />
        <div className="steps">
            <div className="step">
                <img src={step1} alt="" height={60} width={60} />
                <p>Register and get an individual address in the USA, Russia, Great Britain, China and UAE (Dubai) for free</p>
            </div>
            <div className="step">
                <img src={step2} alt="" height={60} width={60} />
                <p>Use the shipping addresses that you have got while shopping online</p>
            </div>
            <div className="step">
                <img src={step3} alt="" height={60} width={60} />
                <p>Get your orders in Armenia and in Artsakh</p>
            </div>
        </div>
    </div>
  )
}

export default HowToStart