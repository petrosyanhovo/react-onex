import React from 'react';
import './smartServices.css';
import Heading from '../Heading/Heading';
import SmartServiceImg from '../SmartServices/img/smart-service.png';


function importAll(r) {
    let images = {};
    r.keys().map((item, index) => { images[item.replace('./', '')] = r(item); });
    return images;
  }
  
  const images = importAll(require.context('../SmartServices/img', false, /\.(png|jpe?g|svg)$/));
  


const SmartServices = () => {
  return (
    <div className='smartServices'>
            <Heading 
        greenHeading = "SMART" 
        heading = "ԾԱՌԱՅՈՒԹՅՈՒՆՆԵՐ" 
        text = "Նախքան առաքանու ԱՄՆ կամ Չինաստանի պահեստ հասնելը դուք կարող եք պատվիրել հետևյալ SMART ծառայությունները"
        />
        <div className="smart-services-section">
            <div className="smart-services-image">
                <img src={SmartServiceImg} alt="" />
            </div>
            <div className="smart-services-content">
                <p><img src={images['photo-camera.png']} />Photo outside</p>
                <p><img src={images['photo-inside.png']} />Photo inside</p>
                <p><img src={images['stop.png']} />Stop</p>
                <p><img src={images['check-order.png']} />Check the order</p>
                <p><img src={images['single-package.png']} />Do not repack</p>
                <p><img src={images['repackaging.png']} />Additional packaging</p>
                <p><img src={images['change-receiver.png']} />Change the Recipient</p>
                <p><img src={images['unboxing.png']} />Divide into parts</p>
                
            </div>
        </div>

    </div>
  )
}

export default SmartServices